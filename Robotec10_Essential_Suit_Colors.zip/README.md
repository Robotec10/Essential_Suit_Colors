## Notice
This mod is an off-branch of More Suit Colors by 404_Dom,
which futher stems from More Suit Colors for More Suits by
akkowo. I curated each color to my personal liking.

## Additional Note
This mod will disable all default suits added by More Suits

## Colors Included
Red, Orange (Default), Yellow, Green, Blue, Cyan,

Magenta, Purple, Brown, Hot Pink, Turquoise, Navy Blue,

Teal, White, Gray, Black, Beige, Olive, Maroon, Lavender